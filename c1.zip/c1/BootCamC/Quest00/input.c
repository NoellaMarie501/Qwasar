#include <stdio.h>

int main(){
   char name;
   printf("%p\n", &name);
   return 0;
}