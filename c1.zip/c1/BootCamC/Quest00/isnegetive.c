#include <stdio.h>

int isnegative(int c){
    if(c<0)return 0;
    else return 1;
}
int main() {
 return 0;
}