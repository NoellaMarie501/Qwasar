#include <string.h>
#include <stdio.h>
int my_square(int x, int y){
    char o = 'o';
    char dash = '-';
    char line = '|';
    if(x !=0 && y !=0){
        for(int i = 0; i <x ; i++){
           // printf("%
        }
    }
}

int main(){
    printf("%1c\n",'c');
    printf("%2c\n",'c');
    printf("%3c\n",'c');
    printf("%4c\n",'c');
    printf("%5c\n",'c');
    printf("%6c\n",'c');
    printf("%7c\n",'c');
    printf("%8c\n",'c');
    printf("%9c\n",'c');
    printf("%10c\n",'c');
    return 0;
}