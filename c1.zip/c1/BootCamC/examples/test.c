#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#define ADD(a,b)  if((a+b) > 0) printf("c is positive"); else printf("c is negative");
int find(){
   int i = 5; 
}

int main(){
    extern int i;
   
   ADD(6,-6);
   //printf("%d\n",);
}