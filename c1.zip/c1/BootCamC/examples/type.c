#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef int Noella_interger;

int main(){
    Noella_interger age = 7;

    printf("%d\n", age);
}