#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int main(){
    int c = 9/5*5;
    int d = 5*9/5;
    printf("c : %d\n d : %d\n", c, d);
}