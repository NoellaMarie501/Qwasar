#include <unistd.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

void custom_printf(const char* format, ...) {
    va_list arg_list;
    va_start(arg_list, format);
    char buffer[256];
    vsnprintf(buffer, sizeof(buffer), format, arg_list);
    va_end(arg_list);
    write(1, buffer, strlen(buffer));
}

int main() {
    int x = 100;
    double d = 23.56;
    char c = 'C';
    char* str = "Custom printf() function!";
    custom_printf("Example of C custom printf() function:\n");
    custom_printf("\nCharacter: %c\n", c);
    custom_printf("String: %s\n", str);
    custom_printf("Integer: %d\n", x);
    custom_printf("Double: %f\n", d);
    return 0;
}
