#include <stdio.h>
#include <unistd.h>

int main() {
   char buffer[1024];
   int n;
   int input[1024]; // Array to store the digits
   int count = 0; // Counter for the number of digits

   printf("Enter a number: ");
   n = read(STDIN_FILENO, buffer, sizeof(buffer));
   int i = 0;
    begin:
   for (; i < n; i++) {
    printf("n = %d", n);
      if (buffer[i] >= '0' && buffer[i] <= '9') {
         input[count] = buffer[i] - '0'; // Convert character to integer
         count++;
      }
    //   if(count == 4){
    //     count = 0;
    //     goto begin;
    //   }
      printf("c %d", count);
   }

   printf("Digits entered: ");
   for (int i = 0; i < count; i++) {
      printf("%d ", input[i]);
   }
   printf("\n");

   return 0;
}
